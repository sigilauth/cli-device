# Sigil CLI Device

> CLI-based testing device for [Sigil Auth](https://sigilauth.com) — PKI-based strong authentication with hardware-backed keys.

**Status:** v0.1.0 (Initial Release)

## What is this?

A command-line tool that simulates a Sigil Auth device for testing and automation. Generates keypairs, registers with servers, receives and signs authentication challenges via WebSocket.

Use this for:
- **Testing:** Automated E2E tests against Sigil servers
- **Development:** Local testing without mobile app
- **CI/CD:** Headless authentication in build pipelines
- **Desktop:** Native desktop client (future)

## Installation

### Linux Package Managers

**Debian/Ubuntu:**
```bash
curl -LO https://github.com/sigilauth/cli-device/releases/latest/download/sigil-device_0.1.0_linux_amd64.deb
sudo dpkg -i sigil-device_0.1.0_linux_amd64.deb
```

**Fedora/RHEL:**
```bash
sudo rpm -i https://github.com/sigilauth/cli-device/releases/latest/download/sigil-device-0.1.0-1.x86_64.rpm
```

**Arch Linux (AUR):**
```bash
# Via AUR helper (recommended)
yay -S sigil-device

# Or download pre-built package
curl -LO https://github.com/sigilauth/cli-device/releases/latest/download/sigil-device-0.1.0-1-x86_64.pkg.tar.zst
sudo pacman -U sigil-device-0.1.0-1-x86_64.pkg.tar.zst
```

**Alpine:**
```bash
curl -LO https://github.com/sigilauth/cli-device/releases/latest/download/sigil-device_0.1.0_linux_amd64.apk
sudo apk add --allow-untrusted sigil-device_0.1.0_linux_amd64.apk
```

**Flatpak (if/when published to Flathub):**
```bash
flatpak install flathub com.wagmilabs.SigilDevice
flatpak run com.wagmilabs.SigilDevice
```

Manifest available in `packaging/flatpak/` for manual builds.

### Homebrew (macOS / Linux)

```bash
brew install sigilauth/tap/sigil-device
```

### Via go install

```bash
go install github.com/sigilauth/cli-device/cmd/sigil-device@latest
```

### From source

```bash
git clone https://github.com/sigilauth/cli-device.git
cd cli-device
go build -o sigil-device ./cmd/sigil-device
```

### Download pre-built binary

Download for your platform from [GitHub Releases](https://github.com/sigilauth/cli-device/releases).

## Shell Completion

Tab completion is automatically enabled after installing via package manager (Debian, Fedora, Arch, Alpine, Homebrew). Completions are installed for:

- **Bash:** `/usr/share/bash-completion/completions/sigil-device`
- **Zsh:** `/usr/share/zsh/site-functions/_sigil-device`
- **Fish:** `/usr/share/fish/vendor_completions.d/sigil-device.fish`

After installation, restart your shell or source the completion file. Tab-complete subcommands and flags:

```bash
sigil-device <TAB>        # Shows: init, pair, register, listen, etc.
sigil-device pair --<TAB>  # Shows: --server
```

## Quick Start

```bash
# 1. Initialize device (generates keypair)
sigil-device init

# 2. Pair with Sigil server
sigil-device pair --server https://sigil.example.com:8443

# 3. Register with relay for push notifications
sigil-device register --relay https://relay.sigilauth.com

# 4. Listen for challenges (auto-approve for testing)
sigil-device listen --relay https://relay.sigilauth.com --auto-approve
```

## Running as a Service

On Linux systems with systemd, you can run `sigil-device` as a persistent background service:

```bash
# Enable and start the service (runs 'listen --auto-approve')
systemctl --user enable sigil-device.service
systemctl --user start sigil-device.service

# Check service status
systemctl --user status sigil-device.service

# View logs
journalctl --user -u sigil-device -f

# Stop the service
systemctl --user stop sigil-device.service
```

The service automatically restarts on failure and starts on login.

**Note:** You must run `init`, `pair`, and `register` commands manually before enabling the service.

## Commands

For detailed command usage, see `man sigil-device` after installation via package manager.

### `init`

Generate a new BIP39 mnemonic and derive ECDSA P-256 keypair.

```bash
sigil-device init
```

Stores state in `~/.sigil-device/state.json` and mnemonic in `~/.sigil-device/mnemonic.txt`.

### `pair`

Register device public key with a Sigil server.

```bash
sigil-device pair --server https://sigil.example.com:8443
```

### `register`

Register device fingerprint with the push relay for WebSocket delivery.

```bash
sigil-device register --relay https://relay.sigilauth.com
```

### `listen`

Listen for incoming challenges via WebSocket.

```bash
# Interactive mode (prompt for each challenge)
sigil-device listen --relay https://relay.sigilauth.com

# Auto-approve mode (for CI/testing)
sigil-device listen --relay https://relay.sigilauth.com --auto-approve
```

### `respond`

Manually fetch and respond to a specific challenge.

```bash
sigil-device respond <challenge-id> --server https://sigil.example.com:8443
```

### `mpa-respond`

Respond to a multi-party authorization request.

```bash
sigil-device mpa-respond <request-id> --server https://sigil.example.com:8443
```

### `decrypt`

Decrypt and return data encrypted to the device's public key.

```bash
sigil-device decrypt <decrypt-id> --server https://sigil.example.com:8443
```

### `whoami`

Display device fingerprint and identity information.

```bash
sigil-device whoami
```

### `unpair`

Deregister from server and clear pairing state.

```bash
sigil-device unpair --server https://sigil.example.com:8443
```

## Configuration

State is stored in `~/.sigil-device/`:

- `state.json` - Device keypair, server info, relay URL (permissions: 0600)
- `mnemonic.txt` - BIP39 mnemonic backup (permissions: 0600)

## Development

### Build

```bash
go build -o sigil-device ./cmd/sigil-device
```

### Test

```bash
# Run all tests with race detector
go test -race -timeout 60s ./...

# Coverage report
go test -cover ./...

# Coverage HTML
go test -coverprofile=coverage.out ./...
go tool cover -html=coverage.out
```

### Release

```bash
# Tag a new release
git tag -a v0.2.0 -m "Release v0.2.0"
git push origin v0.2.0

# GoReleaser builds binaries automatically via GitHub Actions
```

## Architecture

- **cmd/sigil-device/** - CLI entry point and command definitions
- **internal/crypto/** - ECDSA, ECIES, BIP39, HKDF implementations
- **internal/state/** - State management (~/.sigil-device/)
- **internal/listener/** - WebSocket client and challenge processor
- **pkg/client/** - HTTP client for server and relay APIs

## Security

- Private keys never leave `~/.sigil-device/state.json`
- All files created with 0600 permissions (owner read/write only)
- Mnemonic stored separately for backup purposes
- TLS verification mandatory (no opt-out)
- Signature verification on all server messages

## License

AGPL-3.0 - See [LICENSE](LICENSE) for details.

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for development guidelines.
